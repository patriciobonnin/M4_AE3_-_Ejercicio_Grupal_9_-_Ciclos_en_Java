import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * @author Bastián Mariangel
 * @author Roberto Rivas
 * @author Patricio Bonnin
 * @author Ivan Mieres
 *
 * */



public class Main {
    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);
        Capacitacion capacitacion = new Capacitacion();
        Cliente cliente = new Cliente();
        List<Asistentes> asistente = new ArrayList<>();

        // Datos Cliente
        System.out.println("Ingrese el rut de la empresa: ");
        cliente.setRut(leer.nextLine());
        System.out.println("Ingrese el nombre de la empresa: ");
        cliente.setNombre(leer.nextLine());
        System.out.println("Ingrese direccion de la empresa: ");
        cliente.setDireccion(leer.nextLine());
        System.out.println("Ingrese comuna de la empresa");
        cliente.setComuna(leer.nextLine());
        System.out.println("Ingrese teléfono de la empresa: ");
        cliente.setTelefono(leer.nextLine());
        System.out.println();

        //Datos Capacitacion
        System.out.println("Ingrese día de la capacitacion: ");
        capacitacion.setDia(leer.nextLine());
        System.out.println("Ingrese hora de la capacitacion: ");
        capacitacion.setHora(leer.nextLine());
        System.out.println("Ingrese lugar de la capacitacion: ");
        capacitacion.setLugar(leer.nextLine());
        System.out.println("Ingrese duracion de la capacitacion: ");
        capacitacion.setDuracion(leer.nextInt());
        System.out.println("Ingrese cantidad de asistentes: ");
        capacitacion.setCantidadAsistentes(leer.nextInt());

        int menores25 = 0;
        int entre26y35 = 0;
        int mayores35 = 0;

        for(int i = 0; i < capacitacion.getCantidadAsistentes(); i++) {

            leer = new Scanner(System.in);
            if(capacitacion.getCantidadAsistentes() > 0){

            System.out.println("Ingrese el nombre del asistente");
            String nombreAsistente = leer.nextLine();

            System.out.println("Ingrese la edad del asistente");
            int edadAsistente = leer.nextInt();

            asistente.add(new Asistentes(nombreAsistente,edadAsistente));


            if(edadAsistente < 25){
                menores25 += 1;

            }else if (edadAsistente < 35) {

                entre26y35 += 1;
            }else{

                mayores35 += 1;

            }
            }

        }

        //Mostrar Datos capacitacion
        System.out.println("-------------------------------------------------");
        System.out.println("### Datos Empresa: ###");
        System.out.println("Rut Empresa: "+cliente.getRut());
        System.out.println("Nomre empresa: "+cliente.getNombre());
        System.out.println("Dirección empresa: "+cliente.getDireccion());
        System.out.println("Comuna de la Empresa: "+cliente.getComuna());
        System.out.println("Numero de telefono empresa: "+cliente.getTelefono());
        System.out.println("-------------------------------------------------");

        // Datos Capacitacion
        System.out.println("### Datos de Capacitacion: ###");
        System.out.println("Dia: "+capacitacion.getDia());
        System.out.println("Hora: "+capacitacion.getHora());
        System.out.println("Lugar: "+capacitacion.getLugar());
        System.out.println("Duracion "+capacitacion.getDuracion());
        System.out.println("Cantidad de asistentes: "+capacitacion.getCantidadAsistentes());
        System.out.println("-------------------------------------------------");

        //Datos Asistentes
        System.out.println("### Datos de Asistentes ###");
        System.out.println("\nCantidad de asistentes según grupos de edades:");
        System.out.println("Menores a 25 años: " + menores25);
        System.out.println("Entre 26 y 35 años: " + entre26y35);
        System.out.println("Mayores a 35 años: " + mayores35);
        System.out.println("-------------------------------------------------");


    }
}



